package com.bbsw.practice.user.repository;

import com.bbsw.practice.user.model.UserData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserData,Long> {

    boolean existsByUsername(String username);
    Boolean findByUsernameAndPassword(String username, String password);

}
