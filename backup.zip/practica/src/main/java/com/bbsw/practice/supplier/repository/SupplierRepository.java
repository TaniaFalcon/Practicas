package com.bbsw.practice.supplier.repository;

import com.bbsw.practice.item.model.Item;
import com.bbsw.practice.supplier.model.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier,Long>  {

    List<Supplier> findAll();

    List<Supplier> findByNameIn(List<String> names);
    @Query("""
            select supplier
            from Supplier supplier
            left join supplier.itemList item with item = :item
            where supplier.name in (:names) and item is null
            """)
    List<Supplier> findSupplierNamesNotItem(List<String> names, Item item);
}
