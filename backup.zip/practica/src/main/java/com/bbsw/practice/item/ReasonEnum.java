package com.bbsw.practice.item;

public enum ReasonEnum {
    UNAVAILABLE,FLAW,UNEVEN,UNPROVIDER
}
