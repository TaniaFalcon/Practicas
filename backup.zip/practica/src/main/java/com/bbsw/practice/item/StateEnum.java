package com.bbsw.practice.item;

public enum StateEnum {

    ACTIVE, DISCONTINUED

}
