package com.bbsw.practice.item.service;

import com.bbsw.practice.item.StateEnum;
import com.bbsw.practice.item.dto.DesactiveDTO;
import com.bbsw.practice.item.dto.ItemDTO;
import com.bbsw.practice.item.model.Desactive;
import com.bbsw.practice.item.model.Item;
import com.bbsw.practice.item.repository.DesactiveRepository;
import com.bbsw.practice.item.repository.ItemRepository;
import com.bbsw.practice.price.dto.PriceReductionDTO;
import com.bbsw.practice.price.model.PriceReduction;
import com.bbsw.practice.supplier.dto.SupplierDTO;
import com.bbsw.practice.supplier.model.Supplier;
import com.bbsw.practice.supplier.repository.SupplierRepository;
import com.bbsw.practice.user.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class ItemService {

    @Autowired
    ItemRepository itemRepository;
    @Autowired
    SupplierRepository supplierRepository;
    @Autowired
    DesactiveRepository desactiveRepository;
    @Autowired
    UserRepository userRepository;

    ModelMapper modelMapper = new ModelMapper();

    public List<ItemDTO> list(){ //Funciona correctamente
        return itemRepository.findAll().stream().map(item -> {
            ItemDTO itemDTO = modelMapper.map(item,ItemDTO.class);
            itemDTO.setUsername(item.getUsername());
            itemDTO.setPriceReductionDTOList(item.getPriceReductionList().stream().map(priceReduction -> modelMapper.map(priceReduction, PriceReductionDTO.class)).toList());
            itemDTO.setSupplierDTOList(item.getSupplierList().stream().map(supplier -> modelMapper.map(supplier, SupplierDTO.class)).toList());
            itemDTO.setDesactiveDTOList(item.getDesactiveList().stream().map(desactive -> modelMapper.map(desactive, DesactiveDTO.class)).toList());
            return itemDTO;
        }).toList();
    }
    public List<ItemDTO> listByState(StateEnum state){ //Funciona correctamente
        return itemRepository.findByState(state).stream().map(item -> {
            ItemDTO itemDTO = modelMapper.map(item,ItemDTO.class);
            itemDTO.setUsername(item.getUsername());
            itemDTO.setPriceReductionDTOList(item.getPriceReductionList().stream().map(priceReduction -> modelMapper.map(priceReduction, PriceReductionDTO.class)).toList());
            itemDTO.setSupplierDTOList(item.getSupplierList().stream().map(supplier -> modelMapper.map(supplier, SupplierDTO.class)).toList());
            itemDTO.setDesactiveDTOList(item.getDesactiveList().stream().map(desactive -> modelMapper.map(desactive, DesactiveDTO.class)).toList());
            return itemDTO;
        }).toList();
    }
    public Item createUpdate(ItemDTO itemDTO, List<SupplierDTO> supplierDTOList){
        if(itemDTO.getItemCode() == null && itemDTO.getDescription() == null && itemDTO.getState()==StateEnum.ACTIVE){
            throw new NullPointerException("Item Code or/and Description is empty or item is not active");
        }
        Item item = itemRepository.findByItemCode(itemDTO.getItemCode());
        List<Supplier> supplierList = null;
        List<String> suppliersName = new ArrayList<>();
        if(supplierDTOList!=null&&!supplierDTOList.isEmpty()){
            suppliersName =supplierDTOList.stream().map(SupplierDTO::getName).toList();
        }
        if(item==null){
            item = new Item();
            item.setItemCode(itemDTO.getItemCode());
            item.setCreationDate(LocalDate.now());
            item.setState(StateEnum.ACTIVE);
            supplierList = supplierRepository.findByNameIn(suppliersName);
        }
        item.setDescription(itemDTO.getDescription());
        item.setState(itemDTO.getState());
        item.setPrice(itemDTO.getPrice());
        item.setUsername(itemDTO.getUsername());

        if(supplierList==null){
            supplierList=supplierRepository.findSupplierNamesNotItem(suppliersName, item);
        }
        item.addSupplierList(supplierList);
        item.setPriceReductionList(modelMapper.map(itemDTO.getPriceReductionDTOList(), new TypeToken<List<PriceReduction>>() {}.getType()));
        if (item.getPriceReductionList() != null && !item.getPriceReductionList().isEmpty()) {
            item.addPriceReductionList(modelMapper.map(itemDTO.getPriceReductionDTOList(), new TypeToken<List<PriceReduction>>() {}.getType()));
        }
        return itemRepository.save(item);
    }

    public Desactive desactive(DesactiveDTO desactiveDTO, String username){

        Item item = itemRepository.findByItemCode(desactiveDTO.getItem().getItemCode());
        item.setState(StateEnum.DISCONTINUED);
        itemRepository.save(item);

        Desactive desactive = new Desactive();

        desactive.setItem(item);
        if(userRepository.existsByUsername(username)){
            desactive.setUsername(username);
        }
        desactive.setReason(desactiveDTO.getReason());
        desactive.setRegister(LocalDate.now());

        return desactiveRepository.save(desactive);
    }
}
