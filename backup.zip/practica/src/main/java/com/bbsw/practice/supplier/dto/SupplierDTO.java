package com.bbsw.practice.supplier.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SupplierDTO {
    String name;
    String country;
}
