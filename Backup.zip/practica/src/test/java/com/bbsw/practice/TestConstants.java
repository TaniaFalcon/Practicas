package com.bbsw.practice;

import org.springframework.stereotype.Component;

@Component
public class TestConstants {


}
