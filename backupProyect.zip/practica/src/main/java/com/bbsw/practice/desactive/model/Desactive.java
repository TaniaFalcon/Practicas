package com.bbsw.practice.desactive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Table(name="desactiveitems")
public class Desactive {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "desactiveSequence")
    @SequenceGenerator(name = "desactiveSquence", sequenceName = "desactiveSequence", allocationSize = 1, schema = "erp")
    @Column(name="iddesactive")
    Long idDesactive;
    @Column(name="reason")
    String reason;
    @Column(name = "register")
    LocalDate register;
    /*@OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="itemcode", referencedColumnName = "desactive")
    BigDecimal itemCode;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name="username", referencedColumnName = "username")
    String username;*/
}
