package com.bbsw.practice.common.service;

public interface IProyectService {
    public String concatParam(String type, String data);

}
