package com.bbsw.practice.item.controller;

import com.bbsw.practice.item.StateEnum;
import com.bbsw.practice.item.dto.ItemDTO;
import com.bbsw.practice.item.model.Item;
import com.bbsw.practice.item.service.ItemService;
import com.bbsw.practice.price.dto.PriceReductionDTO;
import com.bbsw.practice.supplier.dto.SupplierDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/item")
public class ItemController {
    @Autowired
    private ItemService itemService;

    @GetMapping("/list")
    public ResponseEntity<List<ItemDTO>> list(){
        return new ResponseEntity<>(itemService.list(), HttpStatus.OK);
    }

    @GetMapping("/listbystate")
    public ResponseEntity<List<ItemDTO>> listByState(StateEnum state){
        return new ResponseEntity<>(itemService.listByState(state), HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Item> create(@RequestBody ItemDTO dto){
        return new ResponseEntity<>(itemService.create(dto), HttpStatus.CREATED);
    }

    @PostMapping("/modify")
    public ResponseEntity<Item> modify(@RequestParam BigDecimal itemCode, @RequestParam ItemDTO dtoItem, @RequestParam PriceReductionDTO dtoPrice, @RequestParam SupplierDTO dtoSupplier){
        return new ResponseEntity<>(itemService.modify(itemCode,dtoItem,dtoPrice,dtoSupplier), HttpStatus.CREATED);
    }
}
