package com.bbsw.practice.item.service;

import com.bbsw.practice.item.StateEnum;
import com.bbsw.practice.item.dto.ItemDTO;
import com.bbsw.practice.item.model.Item;
import com.bbsw.practice.item.repository.ItemRepository;
import com.bbsw.practice.price.dto.PriceReductionDTO;
import com.bbsw.practice.price.model.PriceReduction;
import com.bbsw.practice.supplier.dto.SupplierDTO;
import com.bbsw.practice.supplier.model.Supplier;
import com.bbsw.practice.user.dto.UserDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ItemService {

    @Autowired
    ItemRepository itemRepository;

    ModelMapper modelMapper = new ModelMapper();

    public List<ItemDTO> list(){
        return itemRepository.findAll().stream().map(item -> {
            ItemDTO itemDTO = modelMapper.map(item,ItemDTO.class);
            itemDTO.setUsername(modelMapper.map(item.getUserdata(), UserDTO.class));
            itemDTO.setPriceReductionDTOList(item.getPriceReductionList().stream().map(priceReduction -> modelMapper.map(priceReduction, PriceReductionDTO.class)).toList());
            itemDTO.setSupplierDTOList(item.getSupplierList().stream().map(supplier -> modelMapper.map(supplier, SupplierDTO.class)).toList());
            return itemDTO;
        }).toList();
    }
    public List<ItemDTO> listByState(StateEnum state){
        return itemRepository.findByState(state).stream().map(item -> modelMapper.map(item,ItemDTO.class)).toList();
    }
    public Item create(ItemDTO dto){
        if(dto.getItemCode() == null && dto.getDescription() == null){
            throw new NullPointerException("Item Code or/and Description is empty");
        }
        return itemRepository.save(modelMapper.map(dto,Item.class));
    }
    public Item modify(BigDecimal itemCode, ItemDTO dtoItem, PriceReductionDTO dtoPrice, SupplierDTO dtoSupplier){
        ItemDTO itemDTO = modelMapper.map(itemRepository.findByItemCode(itemCode),ItemDTO.class);
        if(itemDTO.getState() == StateEnum.ACTIVE && dtoItem.getDescription() != null){
            itemDTO.setDescription(dtoItem.getDescription());
            itemDTO.setState(dtoItem.getState());
            itemDTO.setPrice(dtoItem.getPrice());
            itemDTO.setCreationDate(dtoItem.getCreationDate());
        }
        Item itemData = modelMapper.map(itemDTO,Item.class);
        if(dtoPrice != null) {
            itemData.getPriceReductionList().add(modelMapper.map(dtoPrice, PriceReduction.class));
        }
        itemData.getSupplierList().forEach(supplierData -> {
            if(!supplierData.getName().equals(dtoSupplier.getName())){
                itemData.getSupplierList().add(modelMapper.map(dtoSupplier, Supplier.class));
            }
        });
        return itemRepository.save(itemData);
    }
    /*public void desactive(ItemDTO dtoItem, DesactiveDTO dtoDesactive){ //Falta comprobacion
        if(dtoItem.getState() == StateEnum.DISCONTINUED){
            Item itemData = modelMapper.map(dtoItem,Item.class);
            Desactive desactiveData = modelMapper.map(dtoDesactive, Desactive.class);
            itemData.getDesactive().setReason(desactiveData.getReason());
            itemData.getDesactive().setRegister(desactiveData.getRegister());
            itemData.getDesactive().setItemCode(desactiveData.getItemCode());
            itemData.getDesactive().setUsername(desactiveData.getUsername());
            itemRepository.save(itemData);
        }
    }*/
}
