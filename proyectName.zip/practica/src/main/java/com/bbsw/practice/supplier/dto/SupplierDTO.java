package com.bbsw.practice.supplier.dto;

import com.bbsw.practice.item.model.ItemData;
import com.bbsw.practice.supplier.model.SupplierData;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SupplierDTO {
    String name;
    String country;
}
