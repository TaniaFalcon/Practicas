package com.bbsw.practice.user.repository;

public interface UserRepository {
}
