package com.bbsw.practice.supplier.model;

import com.bbsw.practice.item.model.ItemData;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
@Table(name="supplierdata")
public class SupplierData {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "supplierSquence")
    @SequenceGenerator(name="supplierSequence", sequenceName = "supplierSequence", allocationSize = 1, schema = "erp")
    @Column(name="idsupplier")
    Long idSupplier;

    @Column(name="name", unique = true)
    String name;

    @Column(name="country")
    String country;

    @ManyToMany(mappedBy = "itemData", cascade = CascadeType.ALL)
    List<ItemData> itemDataList;

}
