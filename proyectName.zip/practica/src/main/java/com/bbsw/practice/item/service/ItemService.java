package com.bbsw.practice.item.service;

import com.bbsw.practice.desactive.dto.DesactiveDTO;
import com.bbsw.practice.desactive.model.DesactiveData;
import com.bbsw.practice.desactive.utils.DesactiveUtils;
import com.bbsw.practice.item.StateEnum;
import com.bbsw.practice.item.dto.ItemDTO;
import com.bbsw.practice.item.model.ItemData;
import com.bbsw.practice.item.repository.ItemRepository;
import com.bbsw.practice.price.dto.PriceReductionDTO;
import com.bbsw.practice.price.utils.PriceReductionsUtils;
import com.bbsw.practice.supplier.dto.SupplierDTO;
import com.bbsw.practice.supplier.utils.SupplierUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ItemService {

    @Autowired
    ItemRepository itemRepository;

    List<ItemDTO> list(){
        return itemRepository.findAll().stream().map(this::toItemDTO).toList();
    }
    List<ItemDTO> listByState(StateEnum state){
        return itemRepository.findByState(state).stream().map(this::toItemDTO).toList();
    }
    void create(ItemDTO dto){
        if(dto.getItemCode() == null && dto.getDescription() == null){
            throw new NullPointerException("Item Code or/and Description is empty");
        }
        itemRepository.save(toItemData(dto));
    }
    void modify(BigDecimal itemCode, ItemDTO dtoItem, PriceReductionDTO dtoPrice, SupplierDTO dtoSupplier){ //Falta comprobacion
        ItemDTO itemDTO = toItemDTO(itemRepository.findByItemCode(itemCode));
        if(itemDTO.getState() == StateEnum.ACTIVE && dtoItem.getDescription() != null){
            itemDTO.setDescription(dtoItem.getDescription());
            itemDTO.setState(dtoItem.getState());
            itemDTO.setPrice(dtoItem.getPrice());
            itemDTO.setCreationDate(dtoItem.getCreationDate());
            itemDTO.setUsername(dtoItem.getUsername());
        }
        ItemData itemData = toItemData(itemDTO);
        if(dtoPrice != null) {
            itemData.getPriceReductionDataList().add(PriceReductionsUtils.toPriceReductionData(dtoPrice));
        }
        itemData.getSupplierDataList().forEach(supplierData -> {
            if(!supplierData.getName().equals(dtoSupplier.getName())){
                itemData.getSupplierDataList().add(SupplierUtils.toSupplierData(dtoSupplier));
            }
        });
    }
    void desactive(ItemDTO dtoItem, DesactiveDTO dtoDesactive){ //Falta comprobacion
        if(dtoItem.getState() == StateEnum.DISCONTINUED){
            ItemData itemData = toItemData(dtoItem);
            DesactiveData desactiveData = DesactiveUtils.toDesactiveData(dtoDesactive);
            itemData.getDesactiveData().setReason(desactiveData.getReason());
            itemData.getDesactiveData().setRegister(desactiveData.getRegister());
            itemData.getDesactiveData().setItemCode(desactiveData.getItemCode());
            itemData.getDesactiveData().setUsername(desactiveData.getUsername());
            itemRepository.save(itemData);
        }
    }

    private ItemData toItemData(ItemDTO dto){
        ItemData entity = new ItemData();
        entity.setItemCode(dto.getItemCode());
        entity.setDescription(dto.getDescription());
        entity.setState(dto.getState());
        entity.setPrice(dto.getPrice());
        entity.setCreationDate(dto.getCreationDate());
        entity.setUsername(dto.getUsername());
        return entity;
    }
    private ItemDTO toItemDTO(ItemData entity){
        ItemDTO dto = new ItemDTO();
        dto.setItemCode(entity.getItemCode());
        dto.setDescription(entity.getDescription());
        dto.setState(entity.getState());
        dto.setPrice(entity.getPrice());
        dto.setCreationDate(entity.getCreationDate());
        dto.setUsername(entity.getUsername());
        return dto;
    }
}
