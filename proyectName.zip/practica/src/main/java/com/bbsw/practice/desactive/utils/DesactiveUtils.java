package com.bbsw.practice.desactive.utils;

import com.bbsw.practice.desactive.dto.DesactiveDTO;
import com.bbsw.practice.desactive.model.DesactiveData;
import com.bbsw.practice.price.dto.PriceReductionDTO;
import com.bbsw.practice.price.model.PriceReductionData;

public class DesactiveUtils {
    public static DesactiveData toDesactiveData(DesactiveDTO dto){
        DesactiveData entity = new DesactiveData();
        entity.setReason(dto.getReason());
        entity.setRegister(dto.getRegister());
        return entity;
    }
    public static DesactiveDTO toDesactiveDTO(DesactiveData entity){
        DesactiveDTO dto = new DesactiveDTO();
        dto.setReason(entity.getReason());
        dto.setRegister(entity.getRegister());
        return dto;
    }
}
