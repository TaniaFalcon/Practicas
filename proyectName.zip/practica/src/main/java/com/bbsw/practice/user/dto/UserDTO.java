package com.bbsw.practice.user.dto;

import com.bbsw.practice.supplier.model.SupplierData;
import com.bbsw.practice.user.model.UserData;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {
    String username;
    String password;

}
