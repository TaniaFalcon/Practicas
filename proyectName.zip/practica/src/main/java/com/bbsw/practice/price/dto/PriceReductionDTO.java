package com.bbsw.practice.price.dto;

import com.bbsw.practice.item.model.ItemData;
import com.bbsw.practice.price.model.PriceReductionData;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class PriceReductionDTO {
    BigDecimal reducedPrice;
    Date startDate;
    Date endDate;


}
