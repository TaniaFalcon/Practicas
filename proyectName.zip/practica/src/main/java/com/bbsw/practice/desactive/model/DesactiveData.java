package com.bbsw.practice.desactive.model;

import com.bbsw.practice.item.model.ItemData;
import com.bbsw.practice.user.model.UserData;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@Table(name="desactiveitems")
public class DesactiveData {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "desactiveSequence")
    @SequenceGenerator(name = "desactiveSquence", sequenceName = "desactiveSequence", allocationSize = 1, schema = "erp")
    @Column(name="iddesactive")
    Long idDesactive;
    @Column(name="reason")
    String reason;
    @Column(name = "register")
    LocalDate register;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="itemCode", referencedColumnName = "itemcode")
    BigDecimal itemCode;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="username", referencedColumnName = "username")
    String username;
}
