package com.bbsw.practice.user.model;

import com.bbsw.practice.desactive.model.DesactiveData;
import com.bbsw.practice.item.model.ItemData;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
@Table(name="userdata")
public class UserData {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userSequence")
    @SequenceGenerator(name="userSequence", sequenceName = "userSequence", allocationSize = 1, schema = "erp")
    @Column(name="iduser")
    Long idUser;

    @Column(name="username", unique = true)
    String username;

    @Column(name="password")
    String password;

    @OneToMany(mappedBy = "userData", cascade = CascadeType.ALL)
    List<ItemData> itemDataList;

    @OneToOne(mappedBy = "userData")
    DesactiveData desactiveData;
}
