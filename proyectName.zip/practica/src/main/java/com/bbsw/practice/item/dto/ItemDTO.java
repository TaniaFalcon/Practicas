package com.bbsw.practice.item.dto;


import com.bbsw.practice.item.StateEnum;
import com.bbsw.practice.item.model.ItemData;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class ItemDTO {
    BigDecimal itemCode;
    String description;
    StateEnum state;
    BigDecimal price;
    LocalDate creationDate;
    String username;

}
