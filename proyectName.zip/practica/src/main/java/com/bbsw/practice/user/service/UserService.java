package com.bbsw.practice.user.service;

import com.bbsw.practice.user.dto.UserDTO;
import com.bbsw.practice.user.model.UserData;
import com.bbsw.practice.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    private UserData toUserData(UserDTO dto){
        UserData entity = new UserData();
        entity.setUsername(dto.getUsername());
        entity.setPassword(dto.getPassword());
        return entity;
    }
    private UserDTO toUserDTO(UserData entity){
        UserDTO dto = new UserDTO();
        dto.setUsername(entity.getUsername());
        dto.setPassword(entity.getPassword());
        return dto;
    }
}
