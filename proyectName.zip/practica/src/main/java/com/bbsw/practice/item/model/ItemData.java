package com.bbsw.practice.item.model;

import com.bbsw.practice.desactive.model.DesactiveData;
import com.bbsw.practice.item.StateEnum;
import com.bbsw.practice.price.model.PriceReductionData;
import com.bbsw.practice.supplier.model.SupplierData;
import com.bbsw.practice.user.model.UserData;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name="itemdata")
public class ItemData {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "itemSequence")
    @SequenceGenerator(name="itemSequence", sequenceName = "itemSequence", allocationSize = 1, schema = "erp")
    @Column(name="iditem")
    Long idItem;

    @Column(name="itemcode", unique = true, nullable = false)
    BigDecimal itemCode;

    @Column(name="description", nullable = false)
    String description;

    @Column(name="state")
    @Enumerated(EnumType.STRING)
    StateEnum state;

    @Column(name="price")
    BigDecimal price;

    @Column(name="creationdate")
    LocalDate creationDate;

    @Column(name="username")
    String username; //A lo mejor quitar

    @ManyToOne
    @JoinColumn(name="username")
    UserData userData;

    @ManyToMany
    @JoinTable(name="item_supplier",
        joinColumns = @JoinColumn(name = "iditem"),
        inverseJoinColumns = @JoinColumn(name = "idsupplier"))
    List<SupplierData> supplierDataList;

    @OneToMany(mappedBy = "itemData", cascade = CascadeType.ALL, orphanRemoval = true)
    List<PriceReductionData> priceReductionDataList;

    @OneToOne(mappedBy = "itemCode")
    DesactiveData desactiveData;


}
