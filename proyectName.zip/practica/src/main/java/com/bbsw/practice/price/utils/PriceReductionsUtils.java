package com.bbsw.practice.price.utils;

import com.bbsw.practice.price.dto.PriceReductionDTO;
import com.bbsw.practice.price.model.PriceReductionData;

public class PriceReductionsUtils {

    public static PriceReductionData toPriceReductionData(PriceReductionDTO dto){
        PriceReductionData entity = new PriceReductionData();
        entity.setReducedPrice(dto.getReducedPrice());
        entity.setStartDate(dto.getStartDate());
        entity.setEndDate(dto.getEndDate());
        return entity;
    }
    public static PriceReductionDTO toPriceReductionDTO(PriceReductionData entity){
        PriceReductionDTO dto = new PriceReductionDTO();
        dto.setReducedPrice(entity.getReducedPrice());
        dto.setStartDate(entity.getStartDate());
        dto.setEndDate(entity.getEndDate());
        return dto;
    }
}
