package com.bbsw.practice.supplier.utils;

import com.bbsw.practice.supplier.dto.SupplierDTO;
import com.bbsw.practice.supplier.model.SupplierData;

public class SupplierUtils {
    public static SupplierData toSupplierData(SupplierDTO dto){
        SupplierData entity = new SupplierData();
        entity.setName(dto.getName());
        entity.setCountry(dto.getCountry());
        return entity;
    }
    public static SupplierDTO toSupplierDTO(SupplierData entity){
        SupplierDTO dto = new SupplierDTO();
        dto.setName(entity.getName());
        dto.setCountry(entity.getCountry());
        return dto;
    }
}
